package com.github.giovandro.citesAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
