package com.github.giovandro.citesAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CitesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CitesApiApplication.class, args);
	}

}
